%TF.GenerationSoftware,Nexus,fab.ts,1*%
%TF.FileFunction,Soldermask,Top*%
%FSLAX46Y46*%
%MOMM*%
%LPD*%
M02*
